#include "mbed.h"
 
// Read location from M8N
 
I2C i2c(I2C_SDA0, I2C_SCL0);
 
const int addr = 0x42;
 
int main() {
    char cmd[2];
    while (1) {
        cmd[0] = 0x01;
        cmd[1] = 0x00;
        i2c.write(addr, cmd, 2);
 
        wait(0.5);
 
        cmd[0] = 0x00;
        i2c.write(addr, cmd, 1);
        i2c.read(addr, cmd, 2);
 
        float loc = (float((cmd[0]<<8)|cmd[1]));
        printf("Loc = %.2f\n", loc`);
    }
}
